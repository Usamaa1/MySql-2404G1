CREATE TABLE `migrations` 
(
    `id`	INT PRIMARY KEY,
    `distance`	INT,
    `days`	INT
);

INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('10484', '1000', '107');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11728', '1531', '56');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11729', '1370', '37');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11732', '1622', '62');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11734', '1491', '58');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11735', '2723', '82');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11736', '1571', '52');
INSERT INTO `migrations` (`id`, `distance`, `days`) VALUES ('11737', '1957', '92');
